import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error

st.title("📈 Sales Forecasting System")

# Load dataset
data = pd.read_csv("sales_dataset.csv")
data.columns = data.columns.str.strip()

# Drop useless columns
for col in ["Date", "Product_ID", "Store_ID"]:
    if col in data.columns:
        data = data.drop(col, axis=1)

# Convert categorical columns (Promotion, Holiday)
data = pd.get_dummies(data, drop_first=True)

# Target
if "Revenue" not in data.columns:
    st.error("Revenue column not found in dataset")
    st.stop()

y = data["Revenue"]
X = data.drop("Revenue", axis=1)

# Train model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)

# Accuracy
pred = model.predict(X_test)
error = mean_absolute_error(y_test, pred)

st.write("📊 Model MAE Error:", round(error, 2))

# Input section
st.subheader("Enter values for prediction:")

input_data = {}

for col in X.columns:
    input_data[col] = st.number_input(col, value=0)

# Predict button
if st.button("Predict"):
    df = pd.DataFrame([input_data])
    result = model.predict(df)
    st.success(f"💰 Predicted Revenue: {result[0]:.2f}")