import pandas as pd
from sklearn.linear_model import LinearRegression

def train_model():
    data = pd.read_csv("sales_dataset.csv")

    # clean column names
    data.columns = data.columns.str.strip()

    # convert Date (optional but safe)
    if "Date" in data.columns:
        data = data.drop("Date", axis=1)

    # convert text columns if needed
    data = pd.get_dummies(data, drop_first=True)

    # target column
    y = data["Revenue"]

    # features
    X = data.drop("Revenue", axis=1)

    model = LinearRegression()
    model.fit(X, y)

    return model, X.columns
